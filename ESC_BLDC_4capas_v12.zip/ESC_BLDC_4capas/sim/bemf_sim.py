"""ngspice transient simulation of the ESC-BLDC BEMF sensing network with the board values.
Motor model of the course (Model_BLDC / ejemplo_BLDC_open_loop): per phase Rm=0.08 ohm, Lm=30 uH,
sinusoidal BEMF e_x = KT*w*sin(theta_e - k*120deg), KT=15e-3 V*s/rad, 7 pole pairs.
Speed is imposed (steady state); 6-step commutation synchronised with the rotor (as in closed loop),
high-side PWM 20 kHz, IRFR1205 as switches (Rds_on 27 mohm) + body diodes, 10 mohm shunts.
Sensing network = schematic: RBEM 39k/3.3k + CBEM, star 3x10k -> 35.7k/3.3k + CDiv, RBUFIN+ 1k,
LM324 buffers G=1+10k/100k=1.1 (output clamped 0..Vcc-1.5 V), LM339 comparator (ideal, no hysteresis)."""
import subprocess, os, json, math, sys
import numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
NG='/home/claude/ngspice/bin/ngspice'
OUT='/home/claude/proj/sim'
VDC=12.0; FPWM=20e3; KE=0.015; PP=7; RM=0.08; LM=30e-6
def netlist(rpm,D,C,CD,ncyc,fn):
    wm=rpm*2*math.pi/60; fe=rpm/60*PP; Te=1/fe; T=ncyc*Te
    sect=lambda h,l: f"( (u(V(thm)-{h})*u({l}-V(thm))) )"
    deg=math.pi/180
    # sectors (theta_e in rad, 0..2pi): A+B- 30-90, A+C- 90-150, B+C- 150-210, B+A- 210-270, C+A- 270-330, C+B- 330-30
    S=lambda a,b: f"(u(V(thm)-{a*deg:.6f})*u({b*deg:.6f}-V(thm)))"
    hiA=f"({S(30,90)}+{S(90,150)})"; hiB=f"({S(150,210)}+{S(210,270)})"; hiC=f"({S(270,330)}+{S(330,360)}+{S(0,30)})"
    loA=f"({S(210,270)}+{S(270,330)})"; loB=f"({S(330,360)}+{S(0,30)}+{S(30,90)})"; loC=f"({S(90,150)}+{S(150,210)})"
    L=[f'* ESC-BLDC BEMF network, {rpm} rpm, D={D}, CBEM={C}, CDiv={CD}',
       f'.param WM={wm} KE={KE} PP={PP} D={D}',
       f'VDC vdc 0 {VDC}',
       'Bth th 0 V={PP*WM*time+1e-9}',
       'Bthm thm 0 V={V(th)-6.283185307*floor(V(th)/6.283185307)}',
       f'VTRI tri 0 PULSE(0 1 0 {0.5/FPWM-1e-9} {0.5/FPWM-1e-9} 1e-9 {1/FPWM})',
       'Bpwm pwm 0 V={u(D-V(tri))}',
       f'BhA hA 0 V={{V(pwm)*{hiA}}}', f'BhB hB 0 V={{V(pwm)*{hiB}}}', f'BhC hC 0 V={{V(pwm)*{hiC}}}',
       f'BlA lA 0 V={{{loA}}}', f'BlB lB 0 V={{{loB}}}', f'BlC lC 0 V={{{loC}}}',
       '.model SWM SW(Ron=0.027 Roff=1e6 Vt=0.5 Vh=0.05)',
       '.model DB D(Is=1e-12 N=1.3 Rs=0.01 Cjo=1n Tt=50n)']
    for x in 'ABC':
        p=x.lower()
        L+= [f'SH{x} vdc {p} h{x} 0 SWM', f'DH{x} {p} vdc DB',
             f'SL{x} {p} s{x} l{x} 0 SWM', f'DL{x} s{x} {p} DB', f'RSH{x} s{x} 0 10m']
    for k,x in enumerate('ABC'):
        p=x.lower()
        L+= [f'RM{x} {p} {p}1 {RM}', f'LM{x} {p}1 {p}2 {LM} IC=0',
             f'BE{x} {p}2 nm V={{KE*WM*sin(V(th)-{k*2*math.pi/3:.6f})}}']
    L+= ['RNM nm 0 1G']
    for x in 'ABC':
        p=x.lower()
        L+= [f'RBH{x} {p} {p}bemf 39k', f'RBL{x} {p}bemf 0 3.3k', f'CB{x} {p}bemf 0 {C}',
             f'RREF{x} {p}bemf {p}ref 1k', f'CADC{x} {p}ref 0 10p',
             f'RIN{x} {p}bemf {p}p 1k', f'B{x}D {p}d 0 V={{min(max(1.1*V({p}p),0),1.8)}}',
             f'RNE{x} {p} neu 10k']
    L+= ['RD1 neu ndiv 35.7k','RD2 ndiv 0 3.3k',f'CD ndiv 0 {CD}','RINN ndiv np 1k','BVN vn 0 V={min(max(1.1*V(np),0),1.8)}']
    for x in 'ABC':
        p=x.lower()
        L+= [f'CBY{x} {p}d vn 100p', f'BC{x} c{x} 0 V={{V(vn)>V({p}d) ? 3.3 : 0}}']
    L+= [f'.tran 0.2u {T} 0 0.25u uic',
         '.options method=gear maxord=2 reltol=1e-3 abstol=1e-9 vntol=1e-5 itl4=200',
         '.control','run',
         f'wrdata {fn} v(a) v(b) v(nm) v(abemf) v(ndiv) v(ad) v(vn) v(cA) v(thm) i(LMA) v(aref)',
         '.endc','.end']
    return '\n'.join(L), Te
def run(rpm,D,C='22n',CD='22n',ncyc=4,tag=None,plot=True):
    tag=tag or f'{rpm}rpm_C{C}'
    fn=f'{OUT}/bemf_{tag}'
    net,Te=netlist(rpm,D,C,CD,ncyc,fn)
    open(fn+'.cir','w').write(net)
    r=subprocess.run([NG,'-b',fn+'.cir'],capture_output=True,text=True,timeout=3000)
    if not os.path.exists(fn+'.data'): print(r.stdout[-2000:],r.stderr[-2000:]); raise SystemExit
    d=np.loadtxt(fn+'.data'); t=d[:,0]
    cols=['va','vb','vnm','abemf','ndiv','ad','vn','cA','thm','ia','aref']
    v={c:d[:,2*i+1] for i,c in enumerate(cols)}
    fe=1/Te; m=t>=2*Te
    # true ZCs of phase A BEMF (floating windows): theta=0 (rising) and pi (falling)
    th=PP*rpm*2*math.pi/60*t
    zcs=[k*math.pi/(PP*rpm*2*math.pi/60) for k in range(int(th[-1]/math.pi)+1)]
    zcs=[z for z in zcs if z>=2*Te and z<=t[-1]-Te/12]
    delays=[]; chatter=[]
    for z in zcs:
        w0=z-Te/12; w1=z+Te/12           # A floating window = 60 deg centred on ZC
        mm=(t>=w0+3e-6)&(t<=w1)
        c=v['cA'][mm]>1.65; tt=t[mm]
        ch=np.where(np.diff(c.astype(int))!=0)[0]
        chatter.append(len(ch))
        if len(ch): delays.append((tt[ch[-1]+1]-z)*fe*360)
        else: delays.append(float('nan'))
    # PWM ripple: phase A terminal vs opamp input in the A-active window (A high: theta 30..150)
    # use mid-active-window samples
    def win(a0,a1):
        th_m=v['thm']; return m&(th_m>a0*math.pi/180)&(th_m<a1*math.pi/180)
    w=win(80,100)
    rip_term=float(np.ptp(v['va'][w])) if w.any() else 0
    rip_in=float(np.ptp(v['abemf'][w])) if w.any() else 0
    st=dict(rpm=rpm,fe_Hz=round(fe,1),D=D,CBEM=C,CDiv=CD,
            Ipk_A=round(float(np.max(np.abs(v['ia'][m]))),2),
            bemf_peak_V=round(KE*rpm*2*math.pi/60,2),
            max_opamp_in_V=round(float(max(v['abemf'][m].max(),v['ndiv'][m].max())),3),
            max_adc_in_V=round(float(v['aref'][m].max()),3), min_adc_in_V=round(float(v['aref'][m].min()),3),
            max_buffer_out_V=round(float(max(v['ad'][m].max(),v['vn'][m].max())),3),
            pwm_ripple_terminal_Vpp=round(rip_term,2), pwm_ripple_opamp_in_mVpp=round(rip_in*1e3,1),
            zc_delay_deg=[round(x,1) for x in delays], zc_delay_us=[round(x/360/fe*1e6,1) for x in delays],
            comparator_transitions_per_window=chatter)
    if plot:
        fig,ax=plt.subplots(4,1,figsize=(12,11),sharex=True)
        tm=t*1e3
        ax[0].plot(tm,v['va'],lw=0.4,label='V fase A (borne)'); ax[0].plot(tm,v['vb'],lw=0.3,alpha=0.5,label='V fase B'); ax[0].plot(tm,v['vnm'],lw=0.6,label='neutre real motor')
        ax[0].set_ylabel('V'); ax[0].legend(loc='upper right',fontsize=8)
        ax[0].set_title(f'ngspice: xarxa BEMF de la placa - {rpm} rpm (f_e={fe:.0f} Hz), D={D}, CBEM=CDiv={C}, PWM 20 kHz')
        ax[1].plot(tm,v['abemf'],lw=0.6,label='A_BEMF (entrada opamp)'); ax[1].plot(tm,v['ndiv'],lw=0.6,label='Neu_div')
        ax[1].axhline(1.8,color='r',ls='--',lw=0.7,label='limit mode comu LM324/LM339 @3.3 V'); ax[1].set_ylabel('V'); ax[1].legend(loc='upper right',fontsize=8)
        ax[2].plot(tm,v['ad'],lw=0.6,label='A_BEMFD (sortida buffer, 2IN-)'); ax[2].plot(tm,v['vn'],lw=0.6,label='VNdivA (2IN+)')
        for z in zcs: ax[2].axvline(z*1e3,color='g',lw=0.6,ls=':')
        ax[2].set_ylabel('V'); ax[2].legend(loc='upper right',fontsize=8)
        ax[3].plot(tm,v['cA'],lw=0.6,label='sortida comparador A (SensorA)')
        for z in zcs: ax[3].axvline(z*1e3,color='g',lw=0.6,ls=':')
        ax[3].set_ylabel('V'); ax[3].set_xlabel('t (ms)  -  linies verdes: pas per zero real de la BEMF A'); ax[3].legend(loc='upper right',fontsize=8)
        ax[3].set_xlim(2*Te*1e3,t[-1]*1e3)
        plt.tight_layout(); plt.savefig(f'{fn}.png',dpi=100); plt.close()
    os.remove(fn+'.data')
    return st
def duty(rpm):
    w=rpm*2*math.pi/60; return round(min(0.95,(3*math.sqrt(3)/math.pi)*KE*w/VDC+0.06),3)
if __name__=='__main__':
    res={'speeds':[],'c_sweep':[]}
    for rpm in (1000,2500,4000):
        st=run(rpm,duty(rpm)); print(json.dumps(st)); res['speeds'].append(st)
    for C in ('4.7n','10n','47n','100n'):
        st=run(2500,duty(2500),C,C,tag=f'sweep_{C}',plot=False); print(json.dumps(st)); res['c_sweep'].append(st)
    json.dump(res,open(f'{OUT}/bemf_results.json','w'),indent=1)
