# ESC BLDC sensorless – esquemático + PCB 4 capas (KiCad 9) · v1.1

Proyecto KiCad autocontenido: `Controlador_BLDC.kicad_pro / .kicad_sch / .kicad_pcb`, librería de huellas local
`ESC_BLDC.pretty` (incluye la huella de la LaunchPad) y `fp-lib-table` del proyecto.
La v1.1 cierra los 6 puntos que no cumplían las pautas de los PDFs (tabla al final).

## Contenido
| Carpeta / fichero | Qué es |
|---|---|
| `Controlador_BLDC.*` | Proyecto KiCad 9 (esquemático, PCB, reglas y clases de red) |
| `gerber/` | Gerbers RS-274X X2 (mm, formato 4.6, cobre en positivo), un fichero por capa, y **un solo** Excellon con PTH y NPTH |
| `BOM_Controlador_BLDC.csv` | Lista de materiales agrupada por valor y huella (154 componentes) |
| `sim/` | Simulación ngspice de la red BEMF (netlists `.cir`, script, resultados `.json`, gráficas) y el `.asc` de LTspice con los valores de la placa |
| `docs/` | Vista de las capas reconstruida **desde los Gerbers** y vista de cobre top/bottom |

## Cómo abrirlo
1. Abrir `Controlador_BLDC.kicad_pro` con KiCad 9.
2. En el PCB pulsar **B** (rellenar zonas): las zonas se guardan sin rellenar.
3. Inspeccionar → **DRC** (con "Refill all zones") y en el esquemático **ERC**.
4. Los Gerbers de `gerber/` ya están generados y comprobados. Si modificas la placa, regénéralos desde KiCad
   (Fabricar → Plot: Gerber, unidades mm, un fichero por capa: F.SilkS, F.Mask, F.Cu, In1.Cu, In2.Cu, B.Cu, B.Mask, B.SilkS, Edge.Cuts;
   Generar taladros: Excellon, mm, **"PTH and NPTH in single file"**).

## Correcciones hechas en el esquemático
| # | Problema encontrado | Corrección |
|---|---|---|
| 1 | LDO LMS8117 conectado al revés: +5 V llegaba al pin 2 (Vout) y +3V3 salía del pin 3 (Vin). Tab (pin 4 = Vout) marcado NC | Pines del símbolo reordenados (Vin a la izquierda, Vout a la derecha) y tab unido a la salida |
| 2 | Dos etiquetas locales `InNeg` cortocircuitaban OpC1 y OpC2 (las dos entradas inversoras de U2) | Etiquetas eliminadas |
| 3 | `RIB1` era la resistencia de ganancia del opamp C y la shunt de la fase B se llamaba `RIB2` | Renombradas: `RBUFIN-6` y `RIB1` |
| 4 | `CBEM_REF_x` eran condensadores **en serie** entre el divisor BEMF y el ADC (bloquean la DC) | Resistencias `RBEM_REF_x` = 1 kΩ |
| 5 | Electrolíticos de semipuente `CxDES2` con el pin 1 (+) en GND | Girados 180° y cambiados a símbolo polarizado |
| 6 | Bootstrap electrolítico con el + en la fase | Cerámico 1 µF 50 V X7R 1206 |
| 7 | L1 = 4,7 µH con el AP1509 (150 kHz): rizado de 4,1 A pp | 39 µH (Bourns SRN6045TA-390M) → 0,5 A pp |
| 8 | CDES1 con valor "100 nF" pero huella de electrolítico | 470 µF 25 V radial |
| 9 | Salida del LMS8117A con cerámico (necesita ESR 0,5–5 Ω) | CPOT5 = 10 µF tántalo case A |
| 10 | U2C/U2D (opamps sin usar) flotando; U4 unidad 4 con entradas NC | Seguidores con IN+ a GND; 4IN+ a GND y 4IN- a +3V3_ANA |
| 11 | LM324/LM339 sin desacoplo | C_U1, C_U2, C_U4 = 100 nF |
| 12 | Faltaba el SPI de 4 hilos (compatibilidad LSE2) | `J_SPI`: SSI0 → PA2 CLK, PA3 FSS, PA4 MISO, PA5 MOSI, GND |
| 13 | Pocos TP de alimentación, ERC, pines libres de la LaunchPad sin marcar | TP_GND1..3, PWR_FLAG, NC en pines libres, 100 nF HF por semipuente (CxHF1) |
| 14 | Redes `3.3V`, `5V`, `FB` | `+3V3`, `+5V`, `VCC`, `GND` (nombres de la pauta) |
| 15 | Huellas vacías o de librerías externas; pasivos en 2512 | Todas en `ESC_BLDC:`; pasivos 1206 (soldadura manual) salvo shunts 2512 1 W |
| 16 | **v1.1** Sin forma de aislar bloques durante el montaje | Puentes 0 Ω 1206: `R0_DCDC` (VCC → buck), `R0_LDO` (LDO → +3V3), `R0_ANA` (+3V3 → bloque BEMF) |
| 17 | **v1.1** Solo había LED en VCC | `LED2` (+5V, 330 Ω) y `LED3` (salida del LDO, 150 Ω) |
| 18 | **v1.1** Nodos sin test point | `J_DRVA/B/C`, `J_BUFIN`, `J_ALIM2` (ver tabla de test points) |
| 19 | **v1.1** Desacoplo entre los planos In1 (GND) e In2 (VCC) | `C_ST1..6` = 100 nF 50 V X7R repartidos por la placa |

## Valores y comprobación (VCC = 12 V, PWM 20 kHz)
| Bloque | Componentes | Valor | Comprobación |
|---|---|---|---|
| Entrada | CDES1 / CPOT1 | 470 µF 25 V / 10 µF 25 V | bulk + cerámico del buck |
| Buck AP1509-50 | L1, D1, CPOT2 | 39 µH, 1N5819, 220 µF 10 V | ΔI = (12−5)·(5/12)/(150k·39µ) = 0,5 A pp; 1N5819 40 V/1 A |
| LDO LMS8117-3.3 | CPOT4 / CPOT5 | 10 µF cer. / 10 µF tántalo | Cout ≥ 10 µF, ESR 0,5–5 Ω; P ≈ 0,26 W |
| Puentes 0 Ω | R0_DCDC, R0_LDO, R0_ANA | 0 Ω 1206 | 1206 0 Ω ≥ 1–2 A, sobra (buck < 0,3 A, 3,3 V < 0,2 A) |
| LEDs alimentación | R1 / R2 / R3 | 1 kΩ / 330 Ω / 150 Ω | VCC: 10 mA; +5V: (5−2)/330 = 9 mA; +3V3: (3,3−2)/150 = 8,7 mA |
| Entradas driver | RxH1/RxL1, CxH1/CxL1 | 33 Ω / 100 pF C0G | τ = 3,3 ns; IR2301 VIH ≥ 2,9 V: compatible 3,3 V |
| Puerta MOSFET | RGxH1/RGxL1 | 33 Ω | t_on ≈ 325 ns, t_off ≈ 186 ns |
| Bootstrap | Cx_BOOT1, D2–D4 | 1 µF X7R, 1N4149 | ΔV = 0,31 V en 2,4 ms (fase OL más larga) |
| Desacoplo driver | CxDES1 / CxDES2 / CxHF1 | 10 µF / 47 µF 25 V / 100 nF | VCC ≥ 10·Cboot; HF junto al drenador |
| Desacoplo de planos | C_ST1..6 | 100 nF 50 V X7R | VCC↔GND repartidos (retorno de AF entre In1 e In2) |
| Shunt | RIx1 | 10 mΩ 1 % 1 W 2512 | 0,25 W a 5 A |
| Divisor BEMF | RBEM_x2 / RBEM_x1 | 39 k / 3,3 k (1 %) | 0,078 → 0,94 V a 12 V |
| Neutro virtual | RNEU_x, Rdiv1, Rdiv2 | 10 k, 35,7 k, 3,3 k | 0,0780 (error 0,08 %) |
| Filtro | CBEM_x1, CDiv1 | 22 nF | Rth 3,04 kΩ → fc 2,38 kHz (**confirmado por SPICE**, ver abajo) |
| Buffers | RBUFIN+ / RBUFIN− / RBUFOUT | 1 k / 100 k / 10 k | G = 1,1 |
| Comparador | Cbypass, RPull | 100 pF C0G, 4,7 kΩ | pull-up a +3V3_ANA |
| ADC / pot | RBEM_REF_x, CPOT3, CDESPOT1 | 1 kΩ, 100 nF | fc pot = 640 Hz |

## Simulación SPICE de la red BEMF (pauta: valores a partir del análisis SPICE)
Simulación transitoria con **ngspice** de la red tal como está en el esquemático: modelo del motor (R, L y BEMF trapezoidal por fase),
puente de 6 MOSFET con conmutación 6-step y PWM de 20 kHz en el high-side, divisores 39k/3,3k + 22 nF, estrella 3×10 k + 35,7k/3,3k + 22 nF,
RBUFIN+ 1 k, buffers ×1,1 y comparadores (sin histéresis, como el LM339). Netlists, script (`bemf_sim.py`), resultados y gráficas en `sim/`.

| Caso (VCC 12 V) | Duty | Máx. entrada opamp / ADC | Rizado PWM en la entrada del opamp | Retardo del cruce por cero | Transiciones del comparador por ventana |
|---|---|---|---|---|---|
| 1000 rpm | 0,28 | 0,33 V | 186 mVpp | 2,8° (≈ 67 µs) | 1 (una ventana con 11 rebotes) |
| 2500 rpm | 0,60 | 0,65 V | 206 mVpp | 7,0° (≈ 67 µs) | 1–3 |
| 4000 rpm | 0,93 | 0,88 V | 53 mVpp | 10,9° (≈ 65 µs) | 1 (limpio) |

Barrido de C del filtro a 2500 rpm: **4,7 nF** → 5–10 rebotes por ventana y 0,71 Vpp de rizado; **10 nF** → hasta 9 rebotes;
**22 nF** → 1–3 (valor elegido); **47 nF** → limpio pero 14,5° de retardo; **100 nF** → 29° y se pierde algún cruce.

Conclusión: 39 k/3,3 k + 22 nF queda confirmado. La entrada máxima de los opamps (0,88 V) está muy por debajo del límite de modo común
del LM324/LM339 a 3,3 V (1,8 V) y la señal del ADC queda entre 0 y 0,88 V. El retardo es casi constante en tiempo (≈ 66 µs = constante del filtro),
así que se compensa en firmware; los rebotes residuales a baja velocidad se filtran en firmware (el LM339 no tiene histéresis).
El `.asc` de LTspice del enunciado se entrega con los parámetros de la placa
(`Rstar=10K RdivH=39K RdivL=3.3K RdivHN=35.7K Cgnd=22n Cbypass=100p`; R36 del neutro pasa a `{RdivHN}`) para repetirlo allí.

![BEMF 2500 rpm](sim/bemf_2500rpm_C22n.png)

## PCB
* 90 × 70 mm, 4 capas, **solo vías pasantes** 0,8/0,5 mm:
  F.Cu señal + relleno GND / **In1.Cu GND plano entero** / **In2.Cu VCC plano entero** / B.Cu señal + relleno GND.
* **Ninguna pista en las capas internas** y ningún corte en In2: ninguna señal cruza una división de plano.
  +5V, +3V3, +3V3_LDO, +3V3_ANA y VCC_DCDC van como pistas anchas (0,8 / 0,5 mm), que es una de las mitigaciones que propone la pauta EMC.
* Reglas: pista y aislamiento mín. 0,3 mm (0,35 mm en FASE_x, I_x, VBx), borde 0,5 mm, taladros en pasos de 0,05 mm.
  Pines de tira 2,54 mm y LaunchPad con taladro 1,0 mm y pad 1,4 mm (valor THT recomendado en la pauta: x = 1 mm, z = 1,4 mm).
  Clases de red: *Potencia* (VCC, FASE) 2,5 mm; *Fase_sense* (I, VB) 0,4/0,35; *Alimentacio* (+5V, BUCKO, VCC_DCDC) 0,8; *Alim_3V3* 0,5.
* Etapa de potencia: 3 parejas DPAK con el nodo de fase hacia J1 (pistas de 2,5 mm), shunt con vías directas a GND, 47 µF + 100 nF en cada drenador.
  Drivers IR2301 y sus pasivos, y los divisores BEMF y el neutro, en la cara inferior bajo cada semipuente.
* LaunchPad encima (BoosterPack XL); debajo solo el bloque analógico (bajo perfil). Ningún test point queda bajo la LaunchPad
  (todos los pines de TP quedan a ≥ 1,3 mm de su contorno).
* Jaula de vías GND en el perímetro (paso 3 mm) y cosido GND en la zona lógica (98 vías).
* Resultado de la comprobación final (geometría exacta): **0 violaciones de DRC, 0 conexiones pendientes, 0 solapes de courtyard,
  0 pistas en capas internas**, planos In1 e In2 continuos (una sola región conectada cada uno). 1691 segmentos de pista y 415 vías.

## Gerbers (comprobados)
* `Controlador_BLDC-{F_Cu, In1_Cu, In2_Cu, B_Cu, F_Mask, B_Mask, F_Silkscreen, B_Silkscreen, Edge_Cuts}.gbr`: RS-274X X2, mm, formato 4.6, polaridad positiva.
* `Controlador_BLDC.drl`: Excellon métrico, PTH y NPTH en un único fichero (esta placa no tiene NPTH).
* Comprobación hecha releyendo los Gerbers (gerbonara): los 580 taladros caen sobre cobre en las 4 capas, el cobre coincide con el diseño,
  la serigrafía no pisa ningún pad, y la extracción de la netlist desde los Gerbers da **0 circuitos abiertos y 0 cortocircuitos** en las 101 redes.

![Gerbers](docs/gerber_check.png)

## Montaje por etapas (pauta de soldadura)
1. Alimentación de entrada: J_DC1, CDES1, LED1/R1. Comprobar VCC (J13) y que LED1 encienda.
2. Etapa de potencia + drivers + LaunchPad (alimentada por USB) **sin** `R0_DCDC`, `R0_LDO` ni `R0_ANA`:
   probar el open loop con el potenciómetro (TP en J_DRVx, J_TPAx, J_VBAx). El potenciómetro no se suelda: va con cables.
3. Buck: soldar `R0_DCDC` → +5V en J12/J10 y LED2.
4. LDO: comprobar +3V3_LDO en J_ALIM2.2 y LED3; soldar `R0_LDO` para alimentar el rail +3V3 (desconectar entonces la alimentación USB de la LaunchPad o usar su selector).
5. Bloque BEMF: soldar opamps/comparadores y `R0_ANA` (test en J3–J8 y J_BUFIN).

## Test points (AD2)
Todas las tiras de test tienen un pin de GND o un TP_GND cerca, y están fuera de la LaunchPad.
| Conector | Pines |
|---|---|
| J_DRVA / J_DRVB / J_DRVC | 1 HinX · 2 LinX · 3 GATE_XH · 4 GATE_XL · 5 GND |
| J_BUFIN | 1–6 BUF1..6_IN+ (entrada + de cada buffer) · 7 U2C_OUT · 8 U2D_OUT · 9 GND |
| J_ALIM2 | 1 VCC_DCDC · 2 +3V3_LDO · 3 +3V3_ANA · 4 LED1_K · 5 LED2_K · 6 LED3_K · 7 GND |
| J2–J13, J_TPAx, J_VBAx, TP_GND1..3 | fases, VB, sensado de corriente, BEMF, VREF, neutro, duty, alimentaciones y GND |

Las señales PWM AH..CL (PE4, PA6, PE5, PA7, PB4, PF1) se miden en los pines macho superiores de la LaunchPad.

## Revisa antes de enviar a fabricar
* Pasar DRC/ERC de KiCad (los avisos "footprint differs from library" están desactivados).
* `courtyards_overlap` está como *warning* por las tiras de pines a tope del banco J3–J6 (en la comprobación no hay solapes).
* Pinout del AP1509 SOP-8L contra el datasheet.
* PF1 (CL) también enciende el LED rojo de la LaunchPad; PD0/PD1 están puenteados con PB6/PB7 en la LaunchPad.
* El LM339 no tiene histéresis: filtrar el cruce por cero en firmware.

## Cumplimiento de los 6 puntos pendientes
| # | Pauta | Estado v1.1 |
|---|---|---|
| 1 | Jumpers / 0 Ω para aislar bloques en las pruebas | ✅ `R0_DCDC`, `R0_LDO`, `R0_ANA` (0 Ω 1206) separan buck, LDO y bloque analógico |
| 2 | LED en las alimentaciones | ✅ LED1 (VCC), LED2 (+5V), LED3 (+3V3 del LDO) |
| 3 | Test points en todos los nodos, accesibles con el AD2 y no bajo la LaunchPad | ✅ Todas las redes llegan a una tira de test, salvo AH..CL, que se miden en los pines de la LaunchPad; ningún pin a menos de 1,3 mm del contorno |
| 4 | No cruzar divisiones de plano | ✅ In1 GND e In2 VCC son planos enteros sin cortes y sin pistas; 6 condensadores de desacoplo entre planos |
| 5 | Valores de la red BEMF a partir de SPICE | ✅ ngspice: 1000/2500/4000 rpm y barrido de C (4,7–100 nF); 39k/3,3k + 22 nF confirmado |
| 6 | Gerbers RS-274X en mm, positivos, un fichero por capa; Excellon con PTH+NPTH juntos | ✅ Generados y verificados: 0 abiertos, 0 cortos, taladros sobre cobre |
